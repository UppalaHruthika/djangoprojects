from django.urls import path
from App1 import views

urlpatterns = [
    path('',views.home,name='ho'),
    path('co/',views.contact_us,name='contact'),
    path('ga/',views.gallery,name='gallery'),
    path('ra/',views.rates,name='rates'),
    path('ou/',views.our_facility,name='ourfacility'),


]